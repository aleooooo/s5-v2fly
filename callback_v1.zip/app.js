const os = require('os')
const request = require('sync-request')
const exec = require('child_process').execSync;
const net = require('net');
const sleep = require('deasync')
const args = process.argv.slice(2)
const host = args[0];
let hostname = os.hostname();

if (typeof host === 'undefined' || typeof hostname === 'undefined') {
    console.log('exit')
    return
}
console.log('host', host, 'hostname', hostname)
//先取附加的IP配置;
let result
result = extra_ip(hostname)
if (result.sts === false) {
    console.log('get extra ip error ' + result.msg)
    return
}
//输出网卡配置;
let extra_ips = result.data.extra_ip
let main_ip = result.data.main_ip
console.log('setNetwork')
result = setNetwork(extra_ips)
if (result.sts === false) {
    console.log('setNetwork error ' + result.msg)
    return
}
console.log('set v2 config')
result = setV2(main_ip, extra_ips)
if (result.sts === false) {
    console.log('setV2 error ' + result.msg)
    return
}

callback(main_ip, extra_ips)


function callback(main_ip, extra_ips) {
    try {
        let ex_ips = []
        ex_ips.push(main_ip)
        extra_ips.forEach(function (item) {
            ex_ips.push(item.ip)
        })
        for (let i = 0; i < 1000000000; i++) {
            let url = host + 'api/v1/proxy/create'
            try {
                console.log('online',ex_ips)
                let res = request('POST', url, {json: ex_ips})

            } catch (e) {}
            sleep.sleep(30000)
        }
        result = {sts: true}
    } catch (e) {
        result = {sts: false, msg: e}
    }
    return result
}

//输出V2配置;
function setV2(main_ip, extra_ips) {
    try {
        let ex_ips = []
        ex_ips.push(main_ip)
        extra_ips.forEach(function (item) {
            ex_ips.push(item.ip)
        })
        let json = {
            inbounds: [],
            outbounds: [],
            routing: {
                rules: []
            }
        }
        let i = 0
        ex_ips.forEach(function (ip) {
            let inbound = {
                listen: ip,
                port: 443,
                protocol: "vmess",
                tag: "in-" + i,
                settings: {
                    clients: [
                        {
                            id: "ffffffff-ffff-ffff-ffff-ffffffffffff",
                            alterId: 0,
                        }
                    ]
                }
            }
            let outbound = {
                sendThrough: ip,
                protocol: "freedom",
                tag: "out-" + i,
                settings: {
                    domainStrategy: "UseIP"
                }
            }
            let rule = {
                type: "field",
                inboundTag: "in-0",
                outboundTag: "out-0"
            }
            json.inbounds.push(inbound)
            json.outbounds.push(outbound)
            json.routing.rules.push(rule)
            i++
        })
        console.log('out v2 config')
        exec("echo -e '" + JSON.stringify(json) + "' > /usr/local/etc/v2ray/config.json")
        console.log('v2 restart')
        exec('systemctl enable v2ray')
        exec('systemctl stop v2ray')
        exec('systemctl start v2ray')
        result = {sts: true}
    } catch (e) {
        result = {sts: false, msg: e}
    }
    return result
}

function setNetwork(data) {
    try {
        let i = 0;
        data.forEach(function (item) {
            i++
            let ip = item.ip
            let netmask = item.netmask
            let gateway = item.gateway
            let cmd = 'echo -e "DEVICE=eth0:' + i + '\nBOOTPROTO=static\nIPADDR=' + ip + '\nNETMASK=' + netmask + '\nGATEWAY=' + gateway + '\nDNS=8.8.8.8\nNBOOT=yes\n" >/etc/sysconfig/network-scripts/ifcfg-eth0:' + i
            exec(cmd)
        })
        if (data.length > 0) {
            //重启网卡服务;
            console.log('restart network')
            exec("service network restart")
        }
        result = {sts: true}
    } catch (e) {
        result = {sts: false, msg: e}
    }
    return result
}

function extra_ip(hostname) {
    let url = host + 'api/v1/vultr/vps/get_once?hostname=' + hostname
    let result
    try {
        let res, js
        res = request('GET', url)
        if (res === false) throw 'get task error: http get error'
        js = JSON.parse(res.getBody())
        if (js.code !== 200) throw js.msg
        result = {sts: true, data: js.data}
    } catch (e) {
        result = {sts: false, msg: e}
    }
    return result
}

function checkIPConnectivity(ipAddress, callback) {
    const socket = net.createConnection(ipAddress, () => {
        socket.end();
        callback(true);
    });

    socket.on('error', () => {
        callback(false);
    });
}